import React from 'react'

function ServicePage() {
  return (
    <div>
      <h1>This is service page</h1>
    </div>
  )
}

export default ServicePage
